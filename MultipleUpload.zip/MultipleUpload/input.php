<!DOCTYPE html>
<html>
<body>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
  Select image to upload:
  <br/><input type="file" name="fileToUpload1" id="fileToUpload"><br/>
  <input type="file" name="fileToUpload2" id="fileToUpload"><br/>
  <input type="file" name="fileToUpload3" id="fileToUpload"><br/>
  <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>

<?php error_reporting(0);
$target_dir = "uploads/";
$target_file1 = $target_dir . basename($_FILES["fileToUpload1"]["name"]);
$target_file2 = $target_dir . basename($_FILES["fileToUpload2"]["name"]);
$target_file3 = $target_dir . basename($_FILES["fileToUpload3"]["name"]);
$uploadOk1 = 1;
$uploadOk2 = 1;
$uploadOk3 = 1;
$imageFileType = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
$imageFileType = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
$imageFileType = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));

$imageFileType = strtolower(pathinfo($target_file3,PATHINFO_EXTENSION));
$imageFileType = strtolower(pathinfo($target_file3,PATHINFO_EXTENSION));
$imageFileType = strtolower(pathinfo($target_file3,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {

  $check = getimagesize($_FILES["fileToUpload1"]["tmp_name"]);
  if($check !== false) {
    //echo "File is an image - " . $check["mime"] . ".";
    $uploadOk1 = 1;
  } else {
    echo "File is not an image.";
    $uploadOk1 = 0;
  }
}

// Check if file already exists
if (file_exists($target_file1)) {
  echo "Sorry, file already exists.";
  $uploadOk1 = 0;
}

// Check file size
if ($_FILES["fileToUpload1"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk1 = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk1 = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk1 == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload1"]["tmp_name"], $target_file1)) {
    echo "The file ". basename( $_FILES["fileToUpload1"]["name"]). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }

//Second File upload-----------

  $check = getimagesize($_FILES["fileToUpload2"]["tmp_name"]);
  if($check !== false) {
    //echo "File is an image - " . $check["mime"] . ".";
    $uploadOk2 = 1;
  } else {
    echo "File is not an image.";
    $uploadOk2 = 0;
  }
}

// Check if file already exists
if (file_exists($target_file2)) {
  echo "Sorry, file already exists.";
  $uploadOk2 = 0;
}

// Check file size
if ($_FILES["fileToUpload2"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk2 = 0;
}


// Check if $uploadOk is set to 0 by an error
if ($uploadOk2 == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload2"]["tmp_name"], $target_file2)) {
    echo "The file ". basename( $_FILES["fileToUpload2"]["name"]). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
//Third File Upload ----------------------

  $check = getimagesize($_FILES["fileToUpload3"]["tmp_name"]);
  if($check !== false) {
    //echo "File is an image - " . $check["mime"] . ".";
    $uploadOk3 = 1;
  } else {
    echo "File is not an image.";
    $uploadOk3 = 0;
  }
}

// Check if file already exists
if (file_exists($target_file3)) {
  echo "Sorry, file already exists.";
  $uploadOk3 = 0;
}

// Check file size
if ($_FILES["fileToUpload3"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk3 = 0;
}



// Check if $uploadOk is set to 0 by an error
if ($uploadOk3 == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload3"]["tmp_name"], $target_file3)) {
    echo "The file ". basename( $_FILES["fileToUpload3"]["name"]). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }

}//end of initial if


?>
