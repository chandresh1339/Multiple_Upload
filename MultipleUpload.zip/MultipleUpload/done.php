
<?php error_reporting(0);
echo $trigger;
?>

<?php error_reporting(0);

$message='';


if(isset($_POST["submit"]))
{
   $s1=$_POST['text19'];
   $relation='';
   foreach($s1 as $row){
      $relation .= $row.',';
       }

       $s2=$_POST['text21'];
   $actype='';
   foreach($s2 as $row){
      $actype .= $row.',';
           }

//$path='uploads/'.$_FILES['filetoUpload']['name'];
//move_uploaded_file($_FILES['filetoUpload']['name'],$path);



$message="<h3>NEW MEMBESHIP FORM</h3> 
<table>
<tr><td ><small>NEW MEMBESHIP FORM SUBMITTED BY CUSTOMER</small></td></tr>
<tr><td><div>
<b>BASIC DETAILS</b></div></td></tr>
<tr><td><b><small>Email</small></b></td><td><small>".$_POST['text11']."</small></td></tr>
<tr><td><b><small>Name</small></b></td><td><small>".$_POST['text18']."</small></td></tr>

<tr><td><b><small>Relation</small></b></td><td><small>".$relation."</small></td></tr>

<tr><td><b><small>A/C Type</small></b></td><td><small>".$actype."</small></td></tr>
</table>
";

try{
require_once "class/PHPMailerAutoload.php";

$mail = new PHPMailer;

//Enable SMTP debugging. 
$mail->SMTPDebug = 4;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "smtp.gmail.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "ibusiness404@gmail.com";                 
$mail->Password = "Itsoft@123";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";                           
//Set TCP port to connect to 
$mail->Port = 587;                                   

$mail->FromEmail = $_POST['txt11'];
$mail->FromName = $_POST['txt18'];

$mail->addAddress("c.jhansiwale@gmail.com", "chandresh");

$mail->WordWrap = 50;


$mail->isHTML(true);


foreach ($_FILES["attachment"]["name"] as $k => $v) {
    $mail->AddAttachment( $_FILES["attachment"]["tmp_name"][$k], $_FILES["attachment"]["name"][$k] );
}



$mail->Subject = "NEW MEMBESHIP FORM";
$mail->Body = $message;

//$mail->AltBody = "This is the plain text version of the email content";

if(!$mail->send()) {
    //echo "Mailer Error: " . $mail->ErrorInfo;
 $trigger='<div class="alert alert-danger">!!YOUR MEMBERSHIP FORM Mailer Error:</div>';
} 
else {
      $trigger='<div class="alert alert-success">!!YOUR MEMBERSHIP FORM SUBMITTED SUCCESSFULLY</div>';
   unlink($path);
}

}//end of try

catch (phpmailerException $e) {
    $errors[] = $e->errorMessage(); //Pretty error messages from PHPMailer
} catch (Exception $e) {
    $errors[] = $e->getMessage(); //Boring error messages from anything else!
}

}//enfd of upper if
?>